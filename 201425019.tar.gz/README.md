# WikiSearch
A search engine made over the entire wikipedia dump.
